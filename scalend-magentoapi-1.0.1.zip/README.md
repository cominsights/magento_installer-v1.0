It is develop by Scalend.

It is used to get data from Magento, we use token-based authentication. we ask the user to generate a token in Magento and pass it on to us.
We use that to call the api and get the data into the system.

1. How to install & upgrade scalend module

It is easy to install, update and maintaince.

Extract "scalend-magentoapi-1.1.1.zip" file and You should create a folder path "app/code/Scalend/MagentoApi".

Run the following command in Magento 2 root folder.

- php bin/magento setup:upgrade

- php bin/magento setup:static-content:deploy

- php bin/magento cache:clean

we need to use manual magento 2 installation ['https://devdocs.magento.com/guides/v2.0/cloud/howtos/install-components.html']

2. How to Use

Use the following steps to generate an access token:

- Log in to Admin and click Store > Configuration > Scalend > Token Configuration to display the Integrations page.

- Enter a unique token id.

- Click to save your changes and return to the Integrations page.

We need to use following way:

- https://<host>//magentoapi/index/products?start_date=yyyy-mm-dd&end_date=yyyy-mm-dd

- https://<host>//magentoapi/index/orders?start_date=yyyy-mm-dd&end_date=yyyy-mm-dd 

- https://<host>//magentoapi/index/customers?start_date=yyyy-mm-dd&end_date=yyyy-mm-dd 

- https://<host>//magentoapi/index/quotes?start_date=yyyy-mm-dd&end_date=yyyy-mm-dd
