<?php
 
namespace Scalend\MagentoApi\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Products extends \Magento\Framework\App\Action\Action
{
     protected $resultJsonFactory;

     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
     {
          $this->resultJsonFactory = $resultJsonFactory;
          return parent::__construct($context);
     }

     public function execute()
     {
          try {
               $tokenId = $this->getBearerToken();
               $startDate = $this->getRequest()->getParam('start_date');
               $endDate = $this->getRequest()->getParam('end_date');
               $storeConfig = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
               $tokenConfig = $storeConfig->getValue('scalend_custom_config/general/token', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
               if($tokenId == $tokenConfig) {
                    $productCollection = $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
                    $collection = $productCollection->create()
                            ->addAttributeToSelect('*');
                            
                    if(!$startDate && !$endDate) {
                          $collection = $productCollection->create()->addAttributeToSelect('*');
                    } else {
                         $fromDate = date('Y-m-d H:i:s', strtotime($startDate));
                         $toDate = date('Y-m-d H:i:s', strtotime($endDate));
                         $collection->addAttributeToFilter('created_at',array('gteq'=>$fromDate))->addAttributeToFilter('created_at',array("lteq" => $toDate));
                    }
                    if(count($collection) > 0) {
                    $arrData = array();
                    foreach ($collection as $product){
                           $productData = [
                              'id' => $product->getId(),
                              'sku' => $product->getSku(),
                              'name' => $product->getName(),
                              'attribute_set_id' => $product->getAttributeSetId(),
                              'price' => $product->getPrice(),
                              'status' => $product->getStatus(),
                              'visibility' => $product->getVisibility(),
                              'type_id' => $product->getTypeId(),
                              'created_at' => $product->getCreatedAt(),
                              'updated_at' => $product->getUpdatedAt(),
                              'weight' => $product->getWeight(),
                              'extension_attributes' => [$this->getExtensionData($product->getSku())],
                              'product_links' => (array) $product->getProductUrl(),
                              'tier_prices' => $product->getTierPrice(),
                              'custom_attributes' => [
                                  [
                                      'attribute_code' => 'description',
                                      'value' => $product->getDescription()

                                  ],
                                  [
                                      'attribute_code' => 'short_description',
                                      'value' => $product->getShortDescription()

                                  ],
                                  [
                                      'attribute_code' => 'meta_title',
                                      'value' => $product->getMetaTitle()

                                  ],
                                  [
                                      'attribute_code' => 'meta_keyword',
                                      'value' => $product->getMetaKeyword()

                                  ],
                                  [
                                      'attribute_code' => 'meta_description',
                                      'value' => $product->getMetaDescription()

                                  ],
                                  [
                                      'attribute_code' => 'image',
                                      'value' => $product->getImage()

                                  ],
                                  [
                                      'attribute_code' => 'small_image',
                                      'value' => $product->getSmallImage()

                                  ],
                                  [
                                      'attribute_code' => 'thumbnail',
                                      'value' => $product->getThumbnail()

                                  ],
                                  [
                                      'attribute_code' => 'options_container',
                                      'value' => $product->getOptionsContainer()

                                  ],
                                  [
                                      'attribute_code' => 'required_options',
                                      'value' => $product->getRequiredOptions()

                                  ],
                                  [
                                      'attribute_code' => 'has_options',
                                      'value' => $product->getHasOptions()

                                  ],
                                  [
                                      'attribute_code' => 'url_key',
                                      'value' => $product->getUrlKey()

                                  ],
                                  [
                                      'attribute_code' => 'swatch_image',
                                      'value' => $product->getSwatchImage()
                                  ],
                                  [
                                      'attribute_code' => 'tax_class_id',
                                      'value' => $product->getTaxClassId()

                                  ],
                                  [
                                      'attribute_code' => 'gift_message_available',
                                      'value' => $product->getGiftMessageAvailable()

                                  ],
                              ],
                            ];
                           $arrData[] = $productData;
                    }
                      if(!$startDate && !$endDate) { 
                          $resultData = [ 
                                'items' => $arrData,
                                'status' => true
                          ]; 
                       } else {
                          $resultData = [ 
                                 'items' => $arrData,
                                 'search_criteria' => $this->getSearchData($fromDate,$toDate,$product->getId()),
                                 'status' => true
                           ]; 
                       }
                    } else {
                         throw new \Exception(__("Product does not exist."));
                    }       
               } else {
                    throw new \Exception(__("Token id does not match."));
               }   
          } catch(\Exception $e) {

               $resultData = ['status' => false, 'message' => $e->getMessage()];
          }   
          return  $this->resultJsonFactory->create()->setData($resultData);
          
     }
     public function getAuthorizationHeader(){
          $headers = null;
          if (isset($_SERVER['Authorization'])) {
              $headers = trim($_SERVER["Authorization"]);
          }
          else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { 
              $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
          } elseif (function_exists('apache_request_headers')) {
              $requestHeaders = apache_request_headers();
              $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
              if (isset($requestHeaders['Authorization'])) {
                  $headers = trim($requestHeaders['Authorization']);
              }
          }
          return $headers;
      }
      /**
       * get access token from header
       * */
      public function getBearerToken() {
          $headers = $this->getAuthorizationHeader();
          if (!empty($headers)) {
              if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
                  return $matches[1];
              }
          }
          return null;
      }
      public function getExtensionData($sku) {
            $this->serviceOutputProcessor = $this->_objectManager->create('Magento\Framework\Webapi\ServiceOutputProcessor');
          $service = $this->_objectManager->get('Magento\Catalog\Api\ProductRepositoryInterface');

        $outputData = call_user_func_array([$service, 'get'], [$sku]);
          $outputData = $this->serviceOutputProcessor->process(
            $outputData,
            'Magento\Catalog\Api\ProductRepositoryInterface',
            'get'
          );

            return $outputData['extension_attributes'];
      }
      public function getSearchData($fromDate,$toDate,$storeId) {
         $arrData = [
            'filter_groups' => [
                  [ 
                    'filters' => [
                        'field' => 'updated_at',
                        'value' => $fromDate,
                        'condition_type' => 'gt',
                    ],
                  ],
                  [ 
                    'filters' => [
                        'field' => 'updated_at',
                        'value' => $toDate,
                        'condition_type' => 'lt',
                    ]
                  ],
                  [ 
                    'filters' => [
                        'field' => 'store_id',
                        'value' => $storeId,
                        'condition_type' => 'eq',
                    ]
                  ]
              ]
          ];
         return $arrData;
      }

}
